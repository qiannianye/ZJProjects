//
//  MonthRecmmdModel.swift
//  Cardqu
//
//  Created by qiannianye on 2018/3/22.
//  Copyright © 2018年 qiannianye. All rights reserved.
//

import Foundation
import HandyJSON

struct MonthRecmmdModel: HandyJSON {
    var id: Int = 0
    var type: Int = 0
    var img_url: String!
}
