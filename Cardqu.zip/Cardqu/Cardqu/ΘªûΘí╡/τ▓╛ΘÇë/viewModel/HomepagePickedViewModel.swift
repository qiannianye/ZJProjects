//
//  HomepagePickedViewModel.swift
//  Cardqu
//
//  Created by qiannianye on 2018/3/26.
//  Copyright © 2018年 qiannianye. All rights reserved.
//

import Foundation

class HomepagePickedViewModel: BaseViewModel {
    
    let sectionArr = ["专题","精选"]
    
    override func fetchSignal() -> AnyAPIProducer {
        return RecommendAPI().homepagePicked().map({ (value) in
            let dic = value as! NSDictionary
            
            let subjectArr = Array<SubjectModel>.deserialize(from: dic["subjects"] as? NSArray)
            let pickedArr = Array<SubjectModel>.deserialize(from: dic["posts"] as? NSArray)
            
            let respArr = [subjectArr,pickedArr]
            return respArr
        })
    }
}
