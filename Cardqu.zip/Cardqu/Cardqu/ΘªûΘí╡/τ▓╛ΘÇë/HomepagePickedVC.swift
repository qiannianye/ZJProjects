//
//  HomepagePickedVC.swift
//  Cardqu
//
//  Created by qiannianye on 2018/3/26.
//  Copyright © 2018年 qiannianye. All rights reserved.
//

import UIKit

class HomepagePickedVC: UIViewController{
    
    private var tableView: UITableView!
    private let viewModel = HomepagePickedViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        
        viewModel.fetchAction.apply(nil).start()
        viewModel.fetchAction.events.observeResult { [unowned self] (result) in
            self.tableView.reloadData()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

extension HomepagePickedVC: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.sectionArr.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0{
            return 1
        }else{
            let arr = viewModel.dataArr[section] as! NSArray
            return arr.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            var autoSV: AutoScrollView!
            var cell = tableView.dequeueReusableCell(withIdentifier: "SubjectCellId")
            if cell == nil{
                cell = UITableViewCell(style: .default, reuseIdentifier: "SubjectCellId")
                
                autoSV = AutoScrollView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 200))
                cell?.contentView.addSubview(autoSV)
                
                //                let collv = UIScrollView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 150))
                //                collv.backgroundColor = UIColor.yellow
                //                cell?.contentView.addSubview(collv)
            }
            
            let arr = viewModel.dataArr[indexPath.section] as? NSArray
            if arr != nil{
                autoSV.images = arr! as [AnyObject]
            }
            return cell!
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: PickedCell.self.description()) as! PickedCell
            
            let arr = viewModel.dataArr[indexPath.section] as? NSArray
            if arr != nil {
                cell.viewModel = arr![indexPath.row] as? PickedCellModel
            }
            return cell
        }
    }
}

extension HomepagePickedVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return screenWidth * 9.0/16.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let sectionHeader = MyinfoSection(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 44))
        sectionHeader.titleLb.textAlignment = NSTextAlignment.center
        sectionHeader.titleLb.text = viewModel.sectionArr[section]
        return sectionHeader
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 44
    }

}

extension HomepagePickedVC {
    func setupUI() {
        view.backgroundColor = UIColor.blue
        
        tableView = UITableView(frame: view.bounds, style: .plain)
        tableView.separatorStyle = .none
        tableView.isScrollEnabled = false //默认不可滑动
        view.addSubview(tableView)
        
        tableView.register(PickedCell.self, forCellReuseIdentifier: PickedCell.self.description())
    }
}

extension HomepagePickedVC {
    func scrollNotification() {
        NotificationCenter.default.addObserver(self, selector: #selector(setScroll), name: NSNotification.Name(rawValue: "SetScroll"), object: nil)
    }
    
    @objc func setScroll(notify: NSNotification) {
        
        let isCanScroll = notify.object as! NSNumber
        tableView.isScrollEnabled = isCanScroll.boolValue
    }
}
