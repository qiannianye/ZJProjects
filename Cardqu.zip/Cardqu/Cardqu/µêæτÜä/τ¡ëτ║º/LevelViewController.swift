//
//  LevelViewController.swift
//  Cardqu
//
//  Created by qiannianye on 2018/3/7.
//  Copyright © 2018年 qiannianye. All rights reserved.
//

import UIKit

class LevelViewController: WebViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


