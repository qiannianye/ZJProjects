//
//  InfoModel.swift
//  Cardqu
//
//  Created by qiannianye on 2018/3/15.
//  Copyright © 2018年 qiannianye. All rights reserved.
//

import UIKit

class InfoModel: BaseModel {
    var title: String!
    var content: String!
    var imgName: String!
    var imgUrl: String!
}
