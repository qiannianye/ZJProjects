//
//  ZJHud.swift
//  Cardqu
//
//  Created by qiannianye on 2017/12/5.
//  Copyright © 2017年 qiannianye. All rights reserved.
//

import UIKit

class ZJHud: UIView {
    
}
