//
//  AppConstans.swift
//  Cardqu
//
//  Created by qiannianye on 2017/11/10.
//  Copyright © 2017年 qiannianye. All rights reserved.
//

import Foundation

struct AppKey {
    static let wxAppID = "wxe117f54378b8b89e"
    static let wxAppSecret = "09a211405a4faa7b1fab8b545c5a90af"
    static let wxPayAppID = "wxeaa9951bca2b6628"
    
    static let tencentAppID = "1104302922"
    static let tencentAppKey = "JSLosw45X4vGKH0f"
    static let tencentRedirectURI = "http://www.cardstay.com"
    
    static let sinaWbAppKey = "2963078254"
    static let sinaWbAppSecret = "ccf69152a33f56516aa8136c9a777f43"
    static let sinaWbRedirectURI = "https://api.weibo.com/oauth2/default.html"
    
    static let gaodeMapAppKey = "c59e73b6d79cb38f81eb8d7b7dcbc6e7"
}
