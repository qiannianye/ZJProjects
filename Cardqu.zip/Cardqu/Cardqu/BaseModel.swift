//
//  BaseModel.swift
//  Cardqu
//
//  Created by qiannianye on 2018/1/24.
//  Copyright © 2018年 qiannianye. All rights reserved.
//

import Foundation

class BaseModel: Codable{ //如何用结构体继承它? 确保值?
    init() {
        
    }
}
