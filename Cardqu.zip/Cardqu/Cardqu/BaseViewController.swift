//
//  BaseViewController.swift
//  Cardqu
//
//  Created by qiannianye on 2017/12/14.
//  Copyright © 2017年 qiannianye. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:设置导航风格
}
